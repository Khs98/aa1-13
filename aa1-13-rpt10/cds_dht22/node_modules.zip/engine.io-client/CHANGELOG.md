## [3.4.4](https://github.com/socketio/engine.io-client/compare/3.4.3...3.4.4) (2020-09-30)



## [3.4.3](https://github.com/socketio/engine.io-client/compare/3.4.2...3.4.3) (2020-06-04)


### Bug Fixes

* **react-native:** restrict the list of options for the WebSocket object ([e5bc106](https://github.com/socketio/engine.io-client/commit/e5bc1063cc90a7b6262146c7b5338ffff1ff9e5b))



## [3.4.2](https://github.com/socketio/engine.io-client/compare/3.4.1...3.4.2) (2020-05-13)



## [3.4.1](https://github.com/socketio/engine.io-client/compare/3.4.0...3.4.1) (2020-04-17)


### Bug Fixes

* use globalThis polyfill instead of self/global ([357f01d](https://github.com/socketio/engine.io-client/commit/357f01d90448d8565b650377bc7cabb351d991bd))



