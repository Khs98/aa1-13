# Installation
> `npm install --save @types/bson`

# Summary
This package contains type definitions for bson (https://github.com/mongodb/js-bson).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bson.

### Additional Details
 * Last updated: Tue, 20 Oct 2020 02:03:19 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Hiroki Horiuchi](https://github.com/horiuchi), [Federico Caselli](https://github.com/CaselIT), [Justin Grant](https://github.com/justingrant), and [Mikael Lirbank](https://github.com/lirbank).
