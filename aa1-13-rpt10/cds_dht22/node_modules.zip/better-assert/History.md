
1.0.0 / 2013-02-03 
==================

  * Stop using the removed magic __stack global getter

0.1.0 / 2012-10-04 
==================

  * add throwing of AssertionError for test frameworks etc

0.0.1 / 2010-01-03
==================

  * Initial release
